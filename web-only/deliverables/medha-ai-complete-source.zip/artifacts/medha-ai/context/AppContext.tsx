import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  createTestDiaryEntries,
  createTestGameProgress,
  createTestNotifications,
  createTestTasks,
  TEST_PATIENT,
  type PatientProfile,
} from '@/data/testPatientData';

export type MicPosition = 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
export type TaskStatus = 'pending' | 'done' | 'snoozed';
export type TaskCategory = 'medicine' | 'hydration' | 'routine' | 'appointment';

export interface DailyTask {
  id: string;
  title: string;
  time: string;
  category: TaskCategory;
  icon: 'heart' | 'droplet' | 'sun' | 'calendar';
  status: TaskStatus;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  time: string;
  kind: 'important' | 'gentle' | 'safety';
  read: boolean;
}

export interface DiaryEntry {
  id: string;
  transcript: string;
  createdAt: string;
  audioUri: string | null;
  audioStatus: 'saved-locally' | 'transcribing' | 'ready-to-record';
  possibleTask?: {
    title: string;
    time: string;
    recurrence: string;
  } | null;
}

export interface GameProgress {
  sessions: number;
  bestScore: number;
  lastScore: number | null;
  lastPlayedAt: string | null;
}

export interface AppSettings {
  language: 'English' | 'Assamese' | 'Hindi';
  highContrast: boolean;
  voicePrompts: boolean;
  notificationsEnabled: boolean;
}

interface PersistedState {
  tasks: DailyTask[];
  notifications: AppNotification[];
  diaryEntries: DiaryEntry[];
  micPosition: MicPosition;
  gameProgress: GameProgress;
  settings: AppSettings;
  testDataActive: boolean;
  patient: PatientProfile | null;
}

interface AppContextValue extends PersistedState {
  isHydrated: boolean;
  completeTask: (taskId: string) => void;
  snoozeTask: (taskId: string) => void;
  markNotificationRead: (notificationId: string) => void;
  setMicPosition: (position: MicPosition) => void;
  addDiaryEntry: (
    transcript: string,
    audioUri: string | null,
    possibleTask?: DiaryEntry['possibleTask'],
  ) => void;
  addVoiceTask: (title: string, time: string, recurrence: string) => void;
  recordGameSession: (score: number) => void;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  loadTestPatientData: () => void;
  deleteTestPatientData: () => void;
}

const STORAGE_KEY = '@medha-ai/app-state';

const defaultState: PersistedState = {
  tasks: createTestTasks(),
  notifications: createTestNotifications(),
  diaryEntries: createTestDiaryEntries(),
  micPosition: 'bottom-right',
  gameProgress: {
    ...createTestGameProgress(),
  },
  settings: {
    language: 'English',
    highContrast: false,
    voicePrompts: true,
    notificationsEnabled: true,
  },
  testDataActive: true,
  patient: TEST_PATIENT,
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<PersistedState>(defaultState);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        if (mounted && stored) {
          try {
            setState({ ...defaultState, ...JSON.parse(stored) } as PersistedState);
          } catch {
            setState(defaultState);
          }
        }
      })
      .finally(() => {
        if (mounted) setIsHydrated(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (isHydrated) {
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => undefined);
    }
  }, [isHydrated, state]);

  const value = useMemo<AppContextValue>(
    () => ({
      ...state,
      isHydrated,
      completeTask: (taskId) => {
        setState((current) => ({
          ...current,
          tasks: current.tasks.map((task) =>
            task.id === taskId ? { ...task, status: 'done' } : task,
          ),
        }));
      },
      snoozeTask: (taskId) => {
        setState((current) => ({
          ...current,
          tasks: current.tasks.map((task) =>
            task.id === taskId ? { ...task, status: 'snoozed' } : task,
          ),
        }));
      },
      markNotificationRead: (notificationId) => {
        setState((current) => ({
          ...current,
          notifications: current.notifications.map((notification) =>
            notification.id === notificationId ? { ...notification, read: true } : notification,
          ),
        }));
      },
      setMicPosition: (micPosition) => setState((current) => ({ ...current, micPosition })),
      addDiaryEntry: (transcript, audioUri, possibleTask) => {
        const entry: DiaryEntry = {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          transcript,
          createdAt: new Date().toISOString(),
          audioUri,
          audioStatus: audioUri ? 'saved-locally' : 'ready-to-record',
          possibleTask,
        };
        setState((current) => ({
          ...current,
          diaryEntries: [entry, ...current.diaryEntries],
        }));
      },
      addVoiceTask: (title, time, recurrence) => {
        const task: DailyTask = {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          title,
          time,
          category: 'routine',
          icon: 'calendar',
          status: 'pending',
        };
        setState((current) => ({
          ...current,
          tasks: [...current.tasks, task],
          notifications: [
            {
              id: `${task.id}-notification`,
              title: 'New reminder added',
              body: `${title} · ${time} · ${recurrence}`,
              time: 'Just now',
              kind: 'gentle',
              read: false,
            },
            ...current.notifications,
          ],
        }));
      },
      recordGameSession: (score) => {
        setState((current) => ({
          ...current,
          gameProgress: {
            sessions: current.gameProgress.sessions + 1,
            bestScore: Math.max(current.gameProgress.bestScore, score),
            lastScore: score,
            lastPlayedAt: new Date().toISOString(),
          },
        }));
      },
      updateSetting: (key, value) => {
        setState((current) => ({
          ...current,
          settings: { ...current.settings, [key]: value },
        }));
      },
      loadTestPatientData: () => {
        setState((current) => ({
          ...current,
          tasks: createTestTasks(),
          notifications: createTestNotifications(),
          diaryEntries: createTestDiaryEntries(),
          gameProgress: createTestGameProgress(),
          testDataActive: true,
          patient: TEST_PATIENT,
        }));
      },
      deleteTestPatientData: () => {
        setState((current) => ({
          ...current,
          tasks: [],
          notifications: [],
          diaryEntries: [],
          gameProgress: { sessions: 0, bestScore: 0, lastScore: null, lastPlayedAt: null },
          testDataActive: false,
          patient: null,
        }));
      },
    }),
    [isHydrated, state],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside AppProvider');
  return context;
}